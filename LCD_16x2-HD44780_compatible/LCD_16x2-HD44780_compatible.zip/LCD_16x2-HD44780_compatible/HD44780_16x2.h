/*
 * HD44780_16x2.h
 *
 *  Created on: Jul 25, 2022
 *      Author: vinca
 */

#ifndef SRC_VIN_HD44780_16X2_H_
#define SRC_VIN_HD44780_16X2_H_

typedef struct HD44780_GPIO_MAP {
	GPIO_TypeDef * RS_port;
	uint16_t RS_pin;
	GPIO_TypeDef * RW_port;
	uint16_t RW_pin;
	GPIO_TypeDef * En_port;
	uint16_t En_pin;
	GPIO_TypeDef * D4_port;
	uint16_t D4_pin;
	GPIO_TypeDef * D5_port;
	uint16_t D5_pin;
	GPIO_TypeDef * D6_port;
	uint16_t D6_pin;
	GPIO_TypeDef * D7_port;
	uint16_t D7_pin;
	uint8_t posR;  // This variable stores the ROW position of the next character.
	uint8_t posC;  // This variable stores the COLUMN position of the next character.
} HD44780_GPIO_map;

int GPIO_config_single_pin(GPIO_TypeDef * port, uint16_t pin, uint32_t mode,
		        uint32_t pull, uint32_t speed);

int HD44780_GPIO_ConfigOUT_4bit(GPIO_TypeDef * RS_port, uint16_t RS_pin,
		                     GPIO_TypeDef * RW_port, uint16_t RW_pin,
							 GPIO_TypeDef * En_port, uint16_t En_pin,
							 GPIO_TypeDef * D4_port, uint16_t D4_pin,
							 GPIO_TypeDef * D5_port, uint16_t D5_pin,
							 GPIO_TypeDef * D6_port, uint16_t D6_pin,
							 GPIO_TypeDef * D7_port, uint16_t D7_pin );


void HD44780_SendChar(char data, char instruction_reg);
int HD44780_init (void) ;
void HD44780_Clear(void);
int HD44780_SetCursorPosition(int row, int col);
int HD44780_SendString(char * buf, int bufsz);


#endif /* SRC_VIN_HD44780_16X2_H_ */
