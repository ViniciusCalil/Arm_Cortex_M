/*
 * HD44780_16x2.c
 *
 *  Created on: Jul 25, 2022
 *      Author: vinca
 */

/**********************************************************
 *
 * Procedure:
 *   1) Call function "HD44780_GPIO_ConfigOUT_4bit()";
 *   2) Call function "HD44780_init ()"
 *   3) Call function "HD44780_SetCursor()"
 *   4) Call:
 *      -) "HD44780_SendChar()" if you want to send an instruction or a single character;
 *      -) "HD44780_SendString()" if you want to send a string of characters;
 *      -) "HD44780_Clear()" if you want to clear all characters present in the display.
 *
 */

#include "stm32f4xx_hal.h"
#include "HD44780_16x2.h"

void HD44780_PrepareNibble(char data, char nibble);
void HD44780_Send_Nibble();
void HD44780_UpdatePosition(void);
void HD44780_SendInitChar(char data);

HD44780_GPIO_map LCD_pin_map = {0};

int HD44780_SendString(char * buf, int bufsz)  {    // (char * buf, int bufsz, char mode) {
	if (buf == NULL) return -1;
	if (bufsz < 0) return -2;

	// HD44780_SendChar(mode, 1);  // Send the instruction that will define how the text will roll or the cursor will increment.
	for(int ix = 0; ix < bufsz; ix++) {
		HD44780_SendChar(*buf, 0);  // Send the data.
		buf++;
	}
	return 0;
}

void HD44780_SendChar(char data, char instruction_reg) {

	//    If "instruction" argument is equal to "0", the HD44780 DATA register
	//    will be written. Otherwise, the INSTRUCTION register will be.
	int bitstate;
	HAL_GPIO_WritePin(LCD_pin_map.RW_port, LCD_pin_map.RW_pin , GPIO_PIN_RESET);  //  Set Write operation.
	bitstate = (!instruction_reg) ? GPIO_PIN_SET : GPIO_PIN_RESET;    //  Selects the LDC Data Register (if instruction == 0) or Instruction Register (if instruction != 0) as target.
	HAL_GPIO_WritePin(LCD_pin_map.RS_port, LCD_pin_map.RS_pin , bitstate);

	// Send the Most Significant Nibble first.
	HD44780_PrepareNibble(data, 1); //(instruction_reg)? 1 : 0);    // (data, 1);
	HD44780_Send_Nibble();

	// Send the Least Significant Nibble latter.
	HD44780_PrepareNibble(data, 0); // (instruction_reg)? 0 : 1);    // (data, 0);
	HD44780_Send_Nibble();

	if (!instruction_reg) HD44780_UpdatePosition();

}

void HD44780_UpdatePosition(void) {
	LCD_pin_map.posC++;
	if (LCD_pin_map.posC == 16){
		LCD_pin_map.posC = 0;
		LCD_pin_map.posR++;
		if (LCD_pin_map.posR == 2) LCD_pin_map.posR = 0;

		HD44780_SetCursorPosition(LCD_pin_map.posR, LCD_pin_map.posC);
	}
}


void HD44780_PrepareNibble(char data, char nibble) {
//    This function write all the pins D4 up to D7 according respective
//    bit values found in "data" argument. If nibble is equal to "0"
//    the bits 0 up to 3 from "data" is written to D04 up to D7, respectively.
//    If nibble is different from "0", the bits 4 up to 7 from "data" is
//    written to D04 up to D7, respectively.

	int bitstate;
	if (nibble) data = data >> 4;

	bitstate =  (data & 0x1) ? GPIO_PIN_SET : GPIO_PIN_RESET;
	HAL_GPIO_WritePin(LCD_pin_map.D4_port, LCD_pin_map.D4_pin , bitstate);

	bitstate =  (data & 0x2) ? GPIO_PIN_SET : GPIO_PIN_RESET;
	HAL_GPIO_WritePin(LCD_pin_map.D5_port, LCD_pin_map.D5_pin , bitstate);

	bitstate =  (data & 0x4) ? GPIO_PIN_SET : GPIO_PIN_RESET;
	HAL_GPIO_WritePin(LCD_pin_map.D6_port, LCD_pin_map.D6_pin , bitstate);

	bitstate =  (data & 0x8) ? GPIO_PIN_SET : GPIO_PIN_RESET;
	HAL_GPIO_WritePin(LCD_pin_map.D7_port, LCD_pin_map.D7_pin , bitstate);
}

void HD44780_Send_Nibble() {
//    This function will enable the transfer of data to the HD44870 LCD.
//    It activates the HD44870 LCD pin "En", wait a millisecond and then it
//    resets the pin "En".

	// After pins "RS" and "RW" are reseted there must be a delay (at least)
	// of 60 nanoseconds before pin "En" can be set.
	// The minimum interval that pin "En" must be set is 450 nanoseconds. But
	// after pins D4 up to D7 are set/reset there must be a delay (at least)
	// of 195 nanoseconds before pin "En" can be reseted.
	// The write operation will happen at the Falling Edge of "En" pin.
	// After "En" pin be reseted, the "D4" up to "D7" pins must remain
	// unchanged for more 10 nanoseconds and pins "RS" and "RW", for
	// more 20 nanoseconds.
	// The "En" pin must remain at low level for (at least) 550 nanoseconds.

	HAL_GPIO_WritePin(LCD_pin_map.En_port, LCD_pin_map.En_pin , GPIO_PIN_SET);    //  Enable LCD to read the data sent from MCU.
	HAL_Delay(1);   // This can be 0.5 microsecond.
	HAL_GPIO_WritePin(LCD_pin_map.En_port, LCD_pin_map.En_pin , GPIO_PIN_RESET);    //  Enable LCD to read the data sent from MCU.
	HAL_Delay(1);   // This can be 0.6 microsecond.

}


int HD44780_GPIO_ConfigOUT_4bit(GPIO_TypeDef * RS_port, uint16_t RS_pin,
		                     GPIO_TypeDef * RW_port, uint16_t RW_pin,
							 GPIO_TypeDef * En_port, uint16_t En_pin,
							 GPIO_TypeDef * D4_port, uint16_t D4_pin,
							 GPIO_TypeDef * D5_port, uint16_t D5_pin,
							 GPIO_TypeDef * D6_port, uint16_t D6_pin,
							 GPIO_TypeDef * D7_port, uint16_t D7_pin ) {
//   This function configures 7 pins to act as digital output to control the
//   HD44780 LCD. The LCD will operate in 4 bit mode, and the pins D4 up to
//   D7 will be OUTPUT.
//   Note: there is no function written to read the HD44780 LCD. So R/W
//         must be keep at low level (write function).

    uint32_t speed = GPIO_SPEED_FREQ_MEDIUM;
    uint32_t mode = GPIO_MODE_OUTPUT_PP;
    uint32_t pull = GPIO_NOPULL;
    int ret;

	ret = GPIO_config_single_pin(RS_port, RS_pin, mode, pull, speed);   // Configure pin for LCD "Register Select" pin.
	if (ret < 0) return -100 + ret;
	ret = GPIO_config_single_pin(RW_port, RW_pin, mode, pull, speed);   // Configure pin for LCD "Read_1/Write_0" pin.
	if (ret < 0) return -200 + ret;
	ret = GPIO_config_single_pin(En_port, En_pin, mode, pull, speed);   // Configure pin for LCD "Enable" pin.
	if (ret < 0) return -300 + ret;

	ret = GPIO_config_single_pin(D4_port, D4_pin, mode, pull, speed);   // Configure pin for LCD "Enable" pin.
	if (ret < 0) return -400 + ret;
	ret = GPIO_config_single_pin(D5_port, D5_pin, mode, pull, speed);   // Configure pin for LCD "Enable" pin.
	if (ret < 0) return -500 + ret;
	ret = GPIO_config_single_pin(D6_port, D6_pin, mode, pull, speed);   // Configure pin for LCD "Enable" pin.
	if (ret < 0) return -600 + ret;
	ret = GPIO_config_single_pin(D7_port, D7_pin, mode, pull, speed);   // Configure pin for LCD "Enable" pin.
	if (ret < 0) return -700 + ret;

	LCD_pin_map.RS_port = RS_port;
	LCD_pin_map.RW_port = RW_port;
	LCD_pin_map.En_port = En_port;
	LCD_pin_map.D4_port = D4_port;
	LCD_pin_map.D5_port = D5_port;
	LCD_pin_map.D6_port = D6_port;
	LCD_pin_map.D7_port = D7_port;

	LCD_pin_map.RS_pin = RS_pin;
	LCD_pin_map.RW_pin = RW_pin;
	LCD_pin_map.En_pin = En_pin;
	LCD_pin_map.D4_pin = D4_pin;
	LCD_pin_map.D5_pin = D5_pin;
	LCD_pin_map.D6_pin = D6_pin;
	LCD_pin_map.D7_pin = D7_pin;

	LCD_pin_map.posC = 0;
    LCD_pin_map.posR = 0;

	return 0;
}

int GPIO_config_single_pin(GPIO_TypeDef * port, uint16_t pin, uint32_t mode,
		        uint32_t pull, uint32_t speed) {
//   This function configures a single GPIO pin to act as digital OUTPUT or
//   INPUT pin.
//   Note: this function will configure only a single pin in a single call.
//         Only GPIO port A, port B and port C are valid.


	//-- Validate the GPIO port: only ports A, B and C are valid in all STM32F4 part numbers
	if(port == GPIOA) {
        __HAL_RCC_GPIOA_CLK_ENABLE();
    } else if (port == GPIOB) {
        __HAL_RCC_GPIOB_CLK_ENABLE();
    } else if (port == GPIOB) {
        __HAL_RCC_GPIOC_CLK_ENABLE();
    } else {
    	return -1;
    }

	//-- Validate a single pin.
	if ((pin != GPIO_PIN_0 ) && (pin != GPIO_PIN_1 ) && (pin != GPIO_PIN_2 ) &&
		(pin != GPIO_PIN_3 ) && (pin != GPIO_PIN_4 ) && (pin != GPIO_PIN_5 ) &&
		(pin != GPIO_PIN_6 ) && (pin != GPIO_PIN_7 ) && (pin != GPIO_PIN_8 ) &&
		(pin != GPIO_PIN_9 ) && (pin != GPIO_PIN_10) && (pin != GPIO_PIN_11) &&
		(pin != GPIO_PIN_12) && (pin != GPIO_PIN_13) && (pin != GPIO_PIN_14) &&
		(pin != GPIO_PIN_15)) return -2;

	//-- Validate pin mode: only digital input or digital output are valid.
	if ((mode !=  GPIO_MODE_INPUT) && (mode !=  GPIO_MODE_OUTPUT_PP) &&
		(mode !=  GPIO_MODE_OUTPUT_OD)) return -3;

	//-- Validate pull-up/pull-down resistor configuration.
	if ((pull != GPIO_NOPULL) && (pull != GPIO_PULLUP) &&
		(pull != GPIO_PULLDOWN) ) return -4;

	//-- Validate port speed
	if ((speed != GPIO_SPEED_FREQ_LOW ) && (speed != GPIO_SPEED_FREQ_MEDIUM) &&
		(speed != GPIO_SPEED_FREQ_HIGH) && (speed != GPIO_SPEED_FREQ_VERY_HIGH) )
		return -5;

	  GPIO_InitTypeDef GPIO_InitStruct = {0};

	  /*Configure GPIO pin : LED_Pin */
	  GPIO_InitStruct.Pin = pin;
	  GPIO_InitStruct.Mode = mode;
	  GPIO_InitStruct.Pull = pull;
	  GPIO_InitStruct.Speed = speed;
	  HAL_GPIO_Init(port, &GPIO_InitStruct);

	  return 0;
}

void HD44780_SendInitChar(char data) {
	//    If "instruction" argument is equal to "0", the HD44780 DATA register
	//    will be written. Otherwise, the INSTRUCTION register will be.
	HAL_GPIO_WritePin(LCD_pin_map.RW_port, LCD_pin_map.RW_pin , GPIO_PIN_RESET);  //  Set Write operation.
	HAL_GPIO_WritePin(LCD_pin_map.RS_port, LCD_pin_map.RS_pin , GPIO_PIN_RESET); //  Selects the LDC Instruction Register as target.

	// Send the Most Significant Nibble first.
	HD44780_PrepareNibble(data, 1);
	HD44780_Send_Nibble();

}

int HD44780_init (void) {
	if ( !LCD_pin_map.D4_port ) return -1;  // The "HD44780_GPIO_ConfigOUT_4bit" function must be caller before this function.

	// Four bit mode initialization.
	HAL_Delay(50);  // wait for >40ms
	HD44780_SendInitChar((char)0x30) ;  // According to Datasheet procedure.
	HAL_Delay(5);  // wait for >4.1ms
	HD44780_SendInitChar((char)0x30) ;  // According to Datasheet procedure.
	HAL_Delay(1);  // wait for >100us
	HD44780_SendInitChar((char)0x30) ;  // According to Datasheet procedure.
	HAL_Delay(10);  // wait maybe for >100us
	HD44780_SendInitChar((char)0x20) ;  // According to Datasheet procedure: fFunction set -->0x"1""DL""N""F""x""x" DL=0 (4 bit mode).
	HAL_Delay(10);  // wait maybe for >100us

  // Display configuration
	HD44780_SendChar((char)0x28, 1) ;    // Function set --> 0x"1""DL""N""F""x""x": DL=0 (4 bits), N=1 (2 line display) F=0 (5x8 characters)
	HAL_Delay(1);  // wait maybe for > 53us
	HD44780_SendChar((char)0x08, 1) ;    //Display on/off control --> 0x"1""D""C""B": D=0 (display off), C=0 (cursor off), B=0 (blink off) . Values defined according initialization. If Necessary change this configuration latter.
	HAL_Delay(1);  // wait maybe for > 53us
	HD44780_SendChar((char)0x01, 1) ;    // Clear display.
	HAL_Delay(5);  // wait maybe for > 3ms
	HD44780_SendChar((char)0x06, 1) ;    //Entry mode set --> 0x"1""I/D""S":  I/D=1 (increment cursor) & S=0 (no shift).
	HAL_Delay(1);  // wait maybe for > 53us

  // display activation
	HD44780_SendChar((char)0x0E, 1) ;    //Display on/off control --> 0x"1""D""C""B": D=1 (display on), C=1 (cursor on), B=0 (blink off) .
	HAL_Delay(1);  // wait maybe for > 53us
	HD44780_SetCursorPosition(0, 0);

	return 0;
}

void HD44780_Clear(void) {
	HD44780_SendChar((char)0x01, 1) ;    // Clear display.
	HAL_Delay(5);  // wait maybe for > 3ms
}


int HD44780_SetCursorPosition(int row, int col) {

// The HD44780 can map 80 characters of 8 bits in the display.
// The position of this characters is the DDRAM Address.
// When the display has two lines, the DDRAM address of the
// first character of the SECOND LINE is always "0x40" and
// the last character of the SECOND LINE is always "0x67".
// When the display has two lines, the DDRAM address of the
// first character of the FIRST LINE is always "0x00" and
// the last character of the FIRST LINE is always "0x27".

	if ((row > 1)  || (row < 0)) return -1;
	if ((col > 15) || (col < 0)) return -2;

	LCD_pin_map.posC = col;
    LCD_pin_map.posR = row;

	char ddram_adr;
    if (row) {
    	ddram_adr = col | 0xC0;   // Row = 1 means second/lower line. DDRAM address for its first/left character is "0x40" value.
    } else {
    	ddram_adr = col | 0x80;   // Row = 0 means first/upper line.  DDRAM address for its first/left character is "0x00" value.
    }

    HD44780_SendChar(ddram_adr, 1);
	HAL_Delay(1);  // wait maybe for > 53us

    return 0;
}
